import { useState, useEffect } from 'react';
import './App.css';

// ===== API Integration CRUD =====

const API_URL = 'http://localhost:3001/tasks';

// CREATE - Add a new task
const createTask = async (description, dueDate) => {
  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ description, dueDate })
    });
    return await response.json();
  } catch (error) {
    console.error("Error creating task:", error);
  }
};

// READ - Fetch all tasks
const fetchTasks = async () => {
  try {
    const response = await fetch(API_URL);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return [];
  }
};

// UPDATE - Update a task
const updateTask = async (taskId, updates) => {
  try {
    const response = await fetch(`${API_URL}/${taskId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates)
    });
    return await response.json();
  } catch (error) {
    console.error("Error updating task:", error);
  }
};

// DELETE - Remove a task
const deleteTask = async (taskId) => {
  try {
    await fetch(`${API_URL}/${taskId}`, {
      method: "DELETE",
    });
  } catch (error) {
    console.error("Error deleting task:", error);
  }
};

// ===== End of API Integration =====

function App() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // Fetch tasks when component loads
  useEffect(() => {
    const loadTasks = async () => {
      const tasks = await fetchTasks();
      setTasks(tasks);
    };
    loadTasks();
  }, []);

  // Add new task handler
  const handleAddTask = async (e) => {
    e.preventDefault();
    if (!newTask.trim()) return;

    const created = await createTask(newTask, dueDate);
    setTasks([...tasks, created]);
    setNewTask("");
    setDueDate("");
  };

  // Apply dark mode to body
  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  }, [isDarkMode]);

  // Theme Toggle handler
  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };
  
  // Check if task is overdue
  const isTaskOverdue = (dateString) => {
    if (!dateString) return false;
    const date = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const taskDate = new Date(date);
    taskDate.setHours(0, 0, 0, 0);
    return taskDate <= today;
  };

  // Toggle complete checkbox
  const toggleComplete = async (task) => {
    // Prevent checking if task is overdue and not already completed
    if (isTaskOverdue(task.dueDate) && !task.isCompleted) {
      return; // Do nothing if trying to check an overdue task
    }
    
    const updated = await updateTask(task._id, { isCompleted: !task.isCompleted });
    setTasks(tasks.map(t => t._id === updated._id ? updated : t));
  };

  // Delete handler
  const handleDelete = async (id) => {
    await deleteTask(id);
    setTasks(tasks.filter(task => task._id !== id));
  };

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return null;
    const date = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const taskDate = new Date(date);
    taskDate.setHours(0, 0, 0, 0);
    
    // Mark as overdue if date is today or earlier
    if (taskDate <= today) {
      return { text: date.toLocaleDateString(), overdue: true };
    }
    return { text: date.toLocaleDateString(), overdue: false };
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>📅 Welcome to Lightaking 🪶</h1>
        <button className="theme-toggle-btn" onClick={toggleTheme}>
          {isDarkMode ? '🌑' : '☀️'}
        </button>
      </header>
      <h2>What's on your mind today?</h2>
      
      {/* Add New Task Form with Image */}
      <form className="add-task-form" onSubmit={handleAddTask}>
        <img 
          src={isDarkMode ? "/SH-dark.png" : "/SH.png"} 
          alt="Lightaking logo" 
          className="task-input-icon" 
        />
        <input
          type="text" 
          placeholder="Add a new task..."
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
        />
        <input
          type="date"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
          className="date-input"
        />
        <button type="submit">Add</button>
      </form>
            
      <div className="task-list">
        {tasks.length === 0 ? (
          <p>Well it seem like there's no important note going on <p>Time for you to take notes!</p></p>
        ) : (
          <ul>
            {tasks.map((task) => {
              const dateInfo = formatDate(task.dueDate);
              const isOverdue = isTaskOverdue(task.dueDate);
              
              return (
                <li key={task._id} className={`task-card ${task.isCompleted ? 'completed' : ''} ${dateInfo?.overdue && !task.isCompleted ? 'overdue' : ''}`}>
                  <input 
                    type="checkbox" 
                    checked={task.isCompleted} 
                    onChange={() => toggleComplete(task)}
                    disabled={isOverdue && !task.isCompleted}
                    className={isOverdue && !task.isCompleted ? 'disabled-checkbox' : ''}
                  />
                  <div className="task-content">
                    <span><strong>{task.description}</strong></span>
                    {dateInfo && (
                      <span className={`due-date ${dateInfo.overdue && !task.isCompleted ? 'overdue-text' : ''}`}>
                        {dateInfo.overdue && !task.isCompleted ? (
                          "Sorry you past the due date, You can do it next time!"
                        ) : (
                          `📅 ${dateInfo.text}`
                        )}
                      </span>
                    )}
                  </div>
                  <button 
                    className="task-delete-btn" 
                    title="Delete task"
                    onClick={() => handleDelete(task._id)}
                  >
                    🗑️
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}

export default App;