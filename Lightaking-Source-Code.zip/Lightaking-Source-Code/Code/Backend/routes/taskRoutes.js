const express = require('express');
const Task = require('../models/Task');

const router = express.Router();

// 3. GET - Get all tasks
router.get('/tasks', async (req, res) => {
  const tasks = await Task.find();
  res.json(tasks);
});

// 4. POST - Create a new task
router.post('/tasks', async (req, res) => {
    console.log('Received request body:', req.body);
    console.log('Due date value:', req.body.dueDate);
    
    const taskData = {
        description: req.body.description,
        isCompleted: false
    };
    
    // Add dueDate if it's provided
    if (req.body.dueDate && req.body.dueDate !== '') {
        taskData.dueDate = req.body.dueDate;
        console.log('Adding dueDate to task:', taskData.dueDate);
    }
    
    console.log('Task data before save:', taskData);
    
    const newTask = new Task(taskData);
    await newTask.save();
    
    console.log('Saved task:', newTask);

    res.json(newTask);
});

// 5. PUT - Update a task (mark as done/not done)
router.put('/tasks/:id', async (req, res) => {
    const taskId = req.params.id;
    
    const updateData = {};
    
    // Update isCompleted if provided
    if (req.body.isCompleted !== undefined) {
        updateData.isCompleted = req.body.isCompleted;
    }
    
    // Update dueDate if provided
    if (req.body.dueDate !== undefined) {
        updateData.dueDate = req.body.dueDate;
    }
    
    // Update description if provided
    if (req.body.description !== undefined) {
        updateData.description = req.body.description;
    }

    const updatedTask = await Task.findByIdAndUpdate(
        taskId, 
        updateData, 
        { new: true }
    );

    res.json(updatedTask);
});

// 6. DELETE - Delete one task
router.delete('/tasks/:id', async (req, res) => {
    const taskId = req.params.id;
    await Task.findByIdAndDelete(taskId);
    res.json({ message: 'Task deleted!' });
});

// 7. DELETE - Delete all tasks
router.delete('/tasks/all', async (req, res) => {
    await Task.deleteMany({});
    res.json({ message: 'All tasks deleted!' });
});

module.exports = router;