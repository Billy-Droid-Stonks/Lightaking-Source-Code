const mongoose = require('mongoose');

// 2. Create the structure for a Task
const taskSchema = new mongoose.Schema({
  description: {
    type: String,
    required: true  // Task description must be provided
  },
  
  isCompleted: {
    type: Boolean,
    default: false  // By default, a task is not completed
  },
  
  dueDate: {
    type: Date,
    required: false  // Due date is optional
  }
}, {
  timestamps: true  // Automatically adds createdAt and updatedAt fields
});

// Create a model from the schema
const Task = mongoose.model('Task', taskSchema);

// Export so other files can use this
module.exports = Task;