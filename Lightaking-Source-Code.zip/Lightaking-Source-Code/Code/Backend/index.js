// Load the libraries we need
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors'); 
const taskRoutes = require('./routes/taskRoutes');

// Create our app and set which port to use
const app = express();
const port = 3001;

// Enable CORS (let the frontend talk to us)
app.use(cors());

// Tell Express to read JSON data
app.use(express.json());

// 1. Connect to the database 
const dbURI = "mongodb+srv://dellusevo_db_user:UJeNx7xI5U5eqhfR@non.fhffsgv.mongodb.net/?appName=Non";

mongoose.connect(dbURI)
  .then(() => console.log('Database connected!'))
  .catch(err => console.log('Database error:', err));

// Use the task routes
app.use('/', taskRoutes);

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
